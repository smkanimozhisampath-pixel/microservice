package com.wipro.coupon.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;
import static org.hamcrest.Matchers.containsString;
import static org.hamcrest.Matchers.startsWith;
import com.wipro.coupon.exception.CouponCodeNotFoundException;
import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.service.CouponService;

@WebMvcTest(CouponController.class)
public class CouponControllerTest {

    private static final String BASE_URL = "/api/v1/coupons";

    @MockitoBean // used to create mock object / dummy object
    private CouponService couponService;
    @MockitoBean
    private com.wipro.coupon.client.ProductClient productClient;
    @Autowired
    private MockMvc mockMvc; // to test the API

    @Autowired
    private ObjectMapper objectMapper;

    private final Random random = new Random();

    // generates a new coupon with random values each time
    private Coupon buildCoupon() {
        Coupon coupon = new Coupon();
        coupon.setId(random.nextInt(1000) + 1);
        coupon.setCode(UUID.randomUUID().toString());
        coupon.setDiscount(random.nextInt(90) + 1);
        coupon.setMaxUses(random.nextInt(500) + 1);
        return coupon;
    }

    @Test // test case
    void testSaveCoupon() throws Exception {
        // arrange
        Coupon actualCouponRequestBody = buildCoupon();

        when(couponService.saveCoupon(any(Coupon.class))).thenReturn(actualCouponRequestBody);

        // act & assert
        mockMvc.perform(post(BASE_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualCouponRequestBody)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(actualCouponRequestBody.getId()))
                .andExpect(jsonPath("$.code").value(actualCouponRequestBody.getCode()));
    }

    @Test
    void testGetCouponById() throws Exception {
        // arrange
        Coupon coupon = buildCoupon();

        when(couponService.findById(coupon.getId())).thenReturn(coupon);

        // act & assert
        mockMvc.perform(get(BASE_URL + "/" + coupon.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(coupon.getId()))
                .andExpect(jsonPath("$.code").value(coupon.getCode()));
    }

    @Test
    void testGetCouponById_CouponNotFound() throws Exception {
        // arrange
        int missingId = random.nextInt(1000) + 1;

        when(couponService.findById(missingId)).thenThrow(new CouponIdNotFoundException(missingId));

        // act & assert
        mockMvc.perform(get(BASE_URL + "/" + missingId))
                .andExpect(status().isNotFound());
        verify(couponService).findById(missingId);
    }

    @Test
    void testGetAllCoupons() throws Exception {
        // arrange
        Coupon first = buildCoupon();
        Coupon second = buildCoupon();
        List<Coupon> coupons = Arrays.asList(first, second);

        when(couponService.findAll()).thenReturn(coupons);

        // act & assert
        mockMvc.perform(get(BASE_URL).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(coupons.size())))
                .andExpect(jsonPath("$[0].code").value(first.getCode()))
                .andExpect(jsonPath("$[1].code").value(second.getCode()));
    }

    @Test
    void testFindByCode() throws Exception {
        // arrange
        Coupon coupon = buildCoupon();
        List<Coupon> coupons = Arrays.asList(coupon);

        when(couponService.findByCode(coupon.getCode())).thenReturn(coupons);

        // act & assert
        mockMvc.perform(get(BASE_URL + "/code/" + coupon.getCode()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(coupons.size())))
                .andExpect(jsonPath("$[0].code").value(coupon.getCode()));
    }
    @Test
    void testWelcome() throws Exception {
        // act & assert
        mockMvc.perform(get(BASE_URL + "/welcome"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value(CouponController.WELCOME_MESSAGE));
    }

    @Test
    void testSaveCoupon_CongratulationsHeader() throws Exception {
        // arrange
        Coupon coupon = buildCoupon();
        when(couponService.saveCoupon(any(Coupon.class))).thenReturn(coupon);

        // act & assert
        mockMvc.perform(post(BASE_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(coupon)))
                .andExpect(status().isCreated())
                .andExpect(header().string("X-Message", CouponController.CREATED_MESSAGE));
    }

    @Test
    void testApplyCoupon() throws Exception {
        // arrange
        Coupon coupon = buildCoupon();
        when(couponService.applyCoupon(coupon.getCode())).thenReturn(coupon);

        // act & assert
        mockMvc.perform(get(BASE_URL + "/apply/" + coupon.getCode()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.message").value(startsWith("Congratulations!")))
                .andExpect(jsonPath("$.message").value(containsString(coupon.getCode())));
    }

    @Test
    void testApplyCoupon_CodeNotFound() throws Exception {
        // arrange
        String missingCode = UUID.randomUUID().toString();
        when(couponService.applyCoupon(missingCode)).thenThrow(new CouponCodeNotFoundException(missingCode));

        // act & assert
        mockMvc.perform(get(BASE_URL + "/apply/" + missingCode))
                .andExpect(status().isNotFound())
                .andExpect(jsonPath("$.message").value(containsString(missingCode)));
    }
}