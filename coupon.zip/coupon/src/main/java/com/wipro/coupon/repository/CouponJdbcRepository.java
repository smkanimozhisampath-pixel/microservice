package com.wipro.coupon.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wipro.coupon.dto.request.Coupon;

@Repository
public class CouponJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public CouponJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // maps one database row to one Coupon object
    private final RowMapper<Coupon> rowMapper = (rs, rowNum) -> {
        Coupon coupon = new Coupon();
        coupon.setId(rs.getInt("id"));
        coupon.setCode(rs.getString("code"));
        coupon.setDiscount(rs.getDouble("discount"));
        coupon.setMaxUses(rs.getInt("max_uses"));
        return coupon;
    };

    public Coupon save(Coupon coupon) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO coupon (code, discount, max_uses) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, coupon.getCode());
            ps.setDouble(2, coupon.getDiscount());
            ps.setInt(3, coupon.getMaxUses());
            return ps;
        }, keyHolder);
        coupon.setId(keyHolder.getKey().intValue());
        return coupon;
    }

    public Optional<Coupon> findById(int id) {
        List<Coupon> result = jdbcTemplate.query(
                "SELECT id, code, discount, max_uses FROM coupon WHERE id = ?", rowMapper, id);
        return result.stream().findFirst();
    }

    public List<Coupon> findAll() {
        return jdbcTemplate.query("SELECT id, code, discount, max_uses FROM coupon", rowMapper);
    }

    public List<Coupon> findByCode(String code) {
        return jdbcTemplate.query(
                "SELECT id, code, discount, max_uses FROM coupon WHERE code = ?", rowMapper, code);
    }
}