package com.wipro.coupon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.client.ProductClient;
import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.dto.response.DiscountedPriceResponse;
import com.wipro.coupon.dto.response.MessageResponse;
import com.wipro.coupon.dto.response.ProductDto;
import com.wipro.coupon.service.CouponService;

@RestController
@RequestMapping("api/v1/coupons")
public class CouponController {

    public static final String WELCOME_MESSAGE = "Welcome to the Coupon API!";
    public static final String CREATED_MESSAGE = "Congratulations! Your coupon was created successfully.";

    private CouponService couponService;
    private ProductClient productClient;

    public CouponController(@Autowired CouponService couponService,
                            @Autowired ProductClient productClient) {
        super();
        this.couponService = couponService;
        this.productClient = productClient;
    }

    @GetMapping("/apply/{code}/product/{productId}")
    public ResponseEntity<DiscountedPriceResponse> applyToProduct(
            @PathVariable String code, @PathVariable int productId) {
        Coupon coupon = couponService.applyCoupon(code);
        ProductDto product = productClient.getProductById(productId);   // Feign call with circuit breaker

        if (product.getId() == -1) {   // fallback was used
            return new ResponseEntity<DiscountedPriceResponse>(
                    new DiscountedPriceResponse(coupon.getCode(), product.getName(), 0, 0, 0),
                    HttpStatus.SERVICE_UNAVAILABLE);
        }

        double finalPrice = product.getPrice() - (product.getPrice() * coupon.getDiscount() / 100);
        return new ResponseEntity<DiscountedPriceResponse>(
                new DiscountedPriceResponse(coupon.getCode(), product.getName(),
                        product.getPrice(), coupon.getDiscount(), finalPrice),
                HttpStatus.OK);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Coupon> getCouponById(@PathVariable int id) {
        return new ResponseEntity<Coupon>(couponService.findById(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Coupon>> getAllCoupons() {
        return new ResponseEntity<List<Coupon>>(couponService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<List<Coupon>> findByCode(@PathVariable String code) {
        return new ResponseEntity<List<Coupon>>(couponService.findByCode(code), HttpStatus.OK);
    }

    @GetMapping("/welcome")
    public ResponseEntity<MessageResponse> welcome() {
        return new ResponseEntity<MessageResponse>(new MessageResponse(WELCOME_MESSAGE), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Message", CREATED_MESSAGE);
        return new ResponseEntity<Coupon>(couponService.saveCoupon(coupon), headers, HttpStatus.CREATED);
    }

    @GetMapping("/apply/{code}")
    public ResponseEntity<MessageResponse> applyCoupon(@PathVariable String code) {
        Coupon coupon = couponService.applyCoupon(code);
        String message = "Congratulations! Coupon " + coupon.getCode()
                + " applied. You get " + coupon.getDiscount() + "% off.";
        return new ResponseEntity<MessageResponse>(new MessageResponse(message), HttpStatus.OK);
    }
    
}