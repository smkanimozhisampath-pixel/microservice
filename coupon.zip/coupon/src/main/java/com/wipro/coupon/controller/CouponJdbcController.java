package com.wipro.coupon.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.dto.response.MessageResponse;
import com.wipro.coupon.service.CouponService;

@RestController
@RequestMapping("api/v1/jdbc/coupons")
public class CouponJdbcController {

    private final CouponService couponService;

    public CouponJdbcController(@Qualifier("couponJdbcService") CouponService couponService) {
        this.couponService = couponService;
    }

    @GetMapping("/welcome")
    public ResponseEntity<MessageResponse> welcome() {
        return new ResponseEntity<MessageResponse>(
                new MessageResponse(CouponController.WELCOME_MESSAGE), HttpStatus.OK);
    }

    @PostMapping
    public ResponseEntity<Coupon> saveCoupon(@RequestBody Coupon coupon) {
        HttpHeaders headers = new HttpHeaders();
        headers.add("X-Message", CouponController.CREATED_MESSAGE);
        return new ResponseEntity<Coupon>(couponService.saveCoupon(coupon), headers, HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Coupon> getCouponById(@PathVariable int id) {
        return new ResponseEntity<Coupon>(couponService.findById(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Coupon>> getAllCoupons() {
        return new ResponseEntity<List<Coupon>>(couponService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/code/{code}")
    public ResponseEntity<List<Coupon>> findByCode(@PathVariable String code) {
        return new ResponseEntity<List<Coupon>>(couponService.findByCode(code), HttpStatus.OK);
    }

    @GetMapping("/apply/{code}")
    public ResponseEntity<MessageResponse> applyCoupon(@PathVariable String code) {
        Coupon coupon = couponService.applyCoupon(code);
        String message = "Congratulations! Coupon " + coupon.getCode()
                + " applied. You get " + coupon.getDiscount() + "% off.";
        return new ResponseEntity<MessageResponse>(new MessageResponse(message), HttpStatus.OK);
    }
}