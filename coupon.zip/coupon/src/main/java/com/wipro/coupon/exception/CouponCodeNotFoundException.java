package com.wipro.coupon.exception;

public class CouponCodeNotFoundException extends RuntimeException {

    public CouponCodeNotFoundException(String code) {
        super("Sorry, coupon code not found: " + code);
    }
}