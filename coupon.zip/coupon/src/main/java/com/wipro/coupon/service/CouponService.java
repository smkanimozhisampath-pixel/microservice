package com.wipro.coupon.service;

import java.util.List;

import com.wipro.coupon.dto.request.Coupon;

public interface CouponService {
    Coupon saveCoupon(Coupon coupon);
    Coupon applyCoupon(String code);
    Coupon findById(int id);
    List<Coupon> findAll();
    List<Coupon> findByCode(String code);
}