package com.wipro.coupon.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.coupon.dto.request.Coupon;
import com.wipro.coupon.exception.CouponCodeNotFoundException;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.repository.CouponJdbcRepository;

@Service("couponJdbcService")
public class CouponJdbcServiceImpl implements CouponService {

    private final CouponJdbcRepository couponJdbcRepository;

    public CouponJdbcServiceImpl(CouponJdbcRepository couponJdbcRepository) {
        this.couponJdbcRepository = couponJdbcRepository;
    }

    @Override
    public Coupon saveCoupon(Coupon coupon) {
        return couponJdbcRepository.save(coupon);
    }

    @Override
    public Coupon findById(int id) {
        return couponJdbcRepository.findById(id)
                .orElseThrow(() -> new CouponIdNotFoundException(id));
    }

    @Override
    public List<Coupon> findAll() {
        return couponJdbcRepository.findAll();
    }

    @Override
    public List<Coupon> findByCode(String code) {
        return couponJdbcRepository.findByCode(code);
    }

    @Override
    public Coupon applyCoupon(String code) {
        List<Coupon> coupons = couponJdbcRepository.findByCode(code);
        if (coupons.isEmpty())
            throw new CouponCodeNotFoundException(code);
        return coupons.get(0);
    }
}