package com.wipro.coupon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.openfeign.EnableFeignClients;
import org.springframework.boot.CommandLineRunner;
import org.springframework.context.annotation.Bean;
@SpringBootApplication
@EnableFeignClients
public class CouponApplication {

	public static void main(String[] args) {
		SpringApplication.run(CouponApplication.class, args);
	}
	@Bean
	public CommandLineRunner welcomeRunner() {
	    return args -> System.out.println("Welcome! Coupon service started on port 8093.");
	}
}
