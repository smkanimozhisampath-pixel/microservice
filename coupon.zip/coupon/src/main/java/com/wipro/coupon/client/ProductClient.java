package com.wipro.coupon.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.wipro.coupon.dto.response.ProductDto;

@FeignClient(name = "PRODUCT", fallback = ProductClientFallback.class)
public interface ProductClient {
	
	@GetMapping("/api/v1/products/port")
	String getProductPort();

    @GetMapping("/api/v1/products/{id}")
    ProductDto getProductById(@PathVariable("id") int id);

    @GetMapping("/api/v1/products")
    List<ProductDto> getAllProducts();
}