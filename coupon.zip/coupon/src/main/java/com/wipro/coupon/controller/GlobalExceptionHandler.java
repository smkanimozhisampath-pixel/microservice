package com.wipro.coupon.controller;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

import com.wipro.coupon.dto.response.ErrorResponse;
import com.wipro.coupon.exception.CouponIdNotFoundException;
import com.wipro.coupon.exception.CouponCodeNotFoundException;
@RestControllerAdvice
public class GlobalExceptionHandler {

    @ExceptionHandler(CouponIdNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleNotFound(CouponIdNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
    }
    @ExceptionHandler(CouponCodeNotFoundException.class)
    public ResponseEntity<ErrorResponse> handleCodeNotFound(CouponCodeNotFoundException ex) {
        ErrorResponse error = new ErrorResponse(HttpStatus.NOT_FOUND.value(), ex.getMessage());
        return new ResponseEntity<ErrorResponse>(error, HttpStatus.NOT_FOUND);
    }
}