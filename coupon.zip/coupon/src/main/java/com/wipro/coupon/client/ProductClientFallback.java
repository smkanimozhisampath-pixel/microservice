package com.wipro.coupon.client;

import java.util.Collections;
import java.util.List;

import org.springframework.stereotype.Component;

import com.wipro.coupon.dto.response.ProductDto;

@Component
public class ProductClientFallback implements ProductClient {

    @Override
    public ProductDto getProductById(int id) {
        ProductDto product = new ProductDto();
        product.setId(-1);   // -1 marks "fallback response"
        product.setName("Product service is currently unavailable");
        return product;
    }

    @Override
    public List<ProductDto> getAllProducts() {
        return Collections.emptyList();
    }

    @Override
    public String getProductPort() {
        return "Product service is currently unavailable";
    }
}