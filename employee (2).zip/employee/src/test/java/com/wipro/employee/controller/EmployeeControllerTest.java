package com.wipro.employee.controller;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.get;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.post;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.jsonPath;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.status;


import java.util.Random;
import java.util.UUID;

import org.assertj.core.util.Arrays;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.http.MediaType;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.service.EmployeeService;
@WebMvcTest(EmployeeController.class)
class EmployeeControllerTest {

private static final String BASE_URL = "/api/v1/employees";

@MockitoBean
private EmployeeService employeeService;

@Autowired
private MockMvc mockMvc;

@Autowired
private ObjectMapper objectMapper;

private final Random random = new Random();

private Employee buildEmployee() {
	Employee employee = new Employee();
	employee.setId(random.nextInt(1000)+1);
	employee.setFirstName(UUID.randomUUID().toString());
	return employee;
}

@Test
void testSaveEmployee() throws Exception {
	Employee actualEmployeeRequestBody = buildEmployee();
	
	when(employeeService.saveEmployee(any(Employee.class))).thenReturn(actualEmployeeRequestBody);
	mockMvc.perform(post(BASE_URL).contentType(MediaType.APPLICATION_JSON)
			.content(objectMapper.writeValueAsString(actualEmployeeRequestBody)))
	.andExpect(status().isCreated())
	.andExpect(jsonPath("$.id").value(actualEmployeeRequestBody.getId()))
	.andExpect(jsonPath("$.firstName").value(actualEmployeeRequestBody.getFirstName()));
	}

@Test
void testGetEmployeeById() throws Exception {
    // arrange
    Employee employee = buildEmployee();

    when(employeeService.findById(employee.getId())).thenReturn(employee);

    // act & assert
    mockMvc.perform(get(BASE_URL + "/" + employee.getId())
                    .contentType(MediaType.APPLICATION_JSON))
            .andExpect(status().isOk())
            .andExpect(jsonPath("$.id").value(employee.getId()))
            .andExpect(jsonPath("$.firstName").value(employee.getFirstName()));
}
}

