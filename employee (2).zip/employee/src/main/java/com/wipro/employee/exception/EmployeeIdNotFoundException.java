package com.wipro.employee.exception;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

@ResponseStatus(HttpStatus.NOT_FOUND)
public class EmployeeIdNotFoundException extends RuntimeException {
private int id;
public EmployeeIdNotFoundException(int id) {
	this.id=id;
	
}
@Override
public String toString() {
	return "Employee Id" + id + " is not found";
}
}
