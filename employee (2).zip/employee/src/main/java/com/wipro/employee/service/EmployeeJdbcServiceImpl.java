package com.wipro.employee.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.employee.dto.request.Employee;
import com.wipro.employee.exception.EmployeeIdNotFoundException;
import com.wipro.employee.repository.EmployeeJdbcRepository;

@Service("employeeJdbcService")
public class EmployeeJdbcServiceImpl implements EmployeeService {

    private final EmployeeJdbcRepository employeeJdbcRepository;

    public EmployeeJdbcServiceImpl(EmployeeJdbcRepository employeeJdbcRepository) {
        this.employeeJdbcRepository = employeeJdbcRepository;
    }

    @Override
    public Employee saveEmployee(Employee employee) {
        return employeeJdbcRepository.save(employee);
    }

    @Override
    public Employee findById(int id) {
        return employeeJdbcRepository.findById(id)
                .orElseThrow(() -> new EmployeeIdNotFoundException(id));
    }

    @Override
    public List<Employee> findAll() {
        return employeeJdbcRepository.findAll();
    }

    @Override
    public Employee findByFirstName(String firstName) {
        return employeeJdbcRepository.findByFirstName(firstName);
    }
}