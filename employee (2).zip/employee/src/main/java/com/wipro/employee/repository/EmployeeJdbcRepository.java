package com.wipro.employee.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wipro.employee.dto.request.Employee;

@Repository
public class EmployeeJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public EmployeeJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // maps one database row to one Employee object
    private final RowMapper<Employee> rowMapper = (rs, rowNum) -> {
        Employee employee = new Employee();
        employee.setId(rs.getInt("id"));
        employee.setFirstName(rs.getString("first_name"));
        return employee;
    };

    public Employee save(Employee employee) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO employee (first_name) VALUES (?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, employee.getFirstName());
            return ps;
        }, keyHolder);
        employee.setId(keyHolder.getKey().intValue());
        return employee;
    }

    public Optional<Employee> findById(int id) {
        List<Employee> result = jdbcTemplate.query(
                "SELECT id, first_name FROM employee WHERE id = ?", rowMapper, id);
        return result.stream().findFirst();
    }

    public List<Employee> findAll() {
        return jdbcTemplate.query("SELECT id, first_name FROM employee", rowMapper);
    }

    public Employee findByFirstName(String firstName) {
        List<Employee> result = jdbcTemplate.query(
                "SELECT id, first_name FROM employee WHERE first_name = ?", rowMapper, firstName);
        return result.isEmpty() ? null : result.get(0);
    }
}