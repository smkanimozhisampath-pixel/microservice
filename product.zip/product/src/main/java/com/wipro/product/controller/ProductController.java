package com.wipro.product.controller;
import org.springframework.beans.factory.annotation.Value;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.wipro.product.dto.request.Product;
import com.wipro.product.service.ProductService;

@RestController
@RequestMapping("api/v1/products")
public class ProductController {
	@Value("${server.port}")
	private String port;
    private ProductService productService;

    public ProductController(@Autowired ProductService productService) {
        super();
        this.productService = productService;
    }

    @PostMapping
    public ResponseEntity<Product> saveProduct(@RequestBody Product product) {
        return new ResponseEntity<Product>(productService.saveProduct(product), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    public ResponseEntity<Product> getProductById(@PathVariable int id) {
        return new ResponseEntity<Product>(productService.findById(id), HttpStatus.OK);
    }

    @GetMapping
    public ResponseEntity<List<Product>> getAllProducts() {
        return new ResponseEntity<List<Product>>(productService.findAll(), HttpStatus.OK);
    }

    @GetMapping("/name/{name}")
    public ResponseEntity<List<Product>> findByName(@PathVariable String name) {
        return new ResponseEntity<List<Product>>(productService.findByName(name), HttpStatus.OK);
        
    }
    @GetMapping("/port")
    public ResponseEntity<String> getPort() {
        return new ResponseEntity<String>("Product instance running on port " + port, HttpStatus.OK);
    }
}