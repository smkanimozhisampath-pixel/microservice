package com.wipro.product.service;

import java.util.List;

import com.wipro.product.dto.request.Product;

public interface ProductService {
    Product saveProduct(Product product);
    Product findById(int id);
    List<Product> findAll();
    List<Product> findByName(String name);
}