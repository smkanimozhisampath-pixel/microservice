package com.wipro.product.service;

import java.util.List;

import org.springframework.stereotype.Service;

import com.wipro.product.dto.request.Product;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.repository.ProductJdbcRepository;

@Service("productJdbcService")
public class ProductJdbcServiceImpl implements ProductService {

    private final ProductJdbcRepository productJdbcRepository;

    public ProductJdbcServiceImpl(ProductJdbcRepository productJdbcRepository) {
        this.productJdbcRepository = productJdbcRepository;
    }

    @Override
    public Product saveProduct(Product product) {
        return productJdbcRepository.save(product);
    }

    @Override
    public Product findById(int id) {
        return productJdbcRepository.findById(id)
                .orElseThrow(() -> new ProductIdNotFoundException(id));
    }

    @Override
    public List<Product> findAll() {
        return productJdbcRepository.findAll();
    }

    @Override
    public List<Product> findByName(String name) {
        return productJdbcRepository.findByName(name);
    }
}