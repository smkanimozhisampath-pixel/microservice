package com.wipro.product.repository;

import java.sql.PreparedStatement;
import java.sql.Statement;
import java.util.List;
import java.util.Optional;

import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.RowMapper;
import org.springframework.jdbc.support.GeneratedKeyHolder;
import org.springframework.jdbc.support.KeyHolder;
import org.springframework.stereotype.Repository;

import com.wipro.product.dto.request.Product;

@Repository
public class ProductJdbcRepository {

    private final JdbcTemplate jdbcTemplate;

    public ProductJdbcRepository(JdbcTemplate jdbcTemplate) {
        this.jdbcTemplate = jdbcTemplate;
    }

    // maps one database row to one Product object
    private final RowMapper<Product> rowMapper = (rs, rowNum) -> {
        Product product = new Product();
        product.setId(rs.getInt("id"));
        product.setName(rs.getString("name"));
        product.setPrice(rs.getDouble("price"));
        product.setQuantity(rs.getInt("quantity"));
        return product;
    };

    public Product save(Product product) {
        KeyHolder keyHolder = new GeneratedKeyHolder();
        jdbcTemplate.update(connection -> {
            PreparedStatement ps = connection.prepareStatement(
                    "INSERT INTO product (name, price, quantity) VALUES (?, ?, ?)",
                    Statement.RETURN_GENERATED_KEYS);
            ps.setString(1, product.getName());
            ps.setDouble(2, product.getPrice());
            ps.setInt(3, product.getQuantity());
            return ps;
        }, keyHolder);
        product.setId(keyHolder.getKey().intValue());
        return product;
    }

    public Optional<Product> findById(int id) {
        List<Product> result = jdbcTemplate.query(
                "SELECT id, name, price, quantity FROM product WHERE id = ?", rowMapper, id);
        return result.stream().findFirst();
    }

    public List<Product> findAll() {
        return jdbcTemplate.query("SELECT id, name, price, quantity FROM product", rowMapper);
    }

    public List<Product> findByName(String name) {
        return jdbcTemplate.query(
                "SELECT id, name, price, quantity FROM product WHERE name = ?", rowMapper, name);
    }
}