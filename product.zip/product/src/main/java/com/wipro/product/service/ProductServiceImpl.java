package com.wipro.product.service;

import java.util.List;
import java.util.Optional;
import org.springframework.context.annotation.Primary;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.wipro.product.dto.request.Product;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.repository.ProductRepository;

import jakarta.transaction.Transactional;
@Primary
@Service
public class ProductServiceImpl implements ProductService {

    private ProductRepository productRepository;

    public ProductServiceImpl(@Autowired ProductRepository productRepository) {
        super();
        this.productRepository = productRepository;
    }

    @Transactional
    @Override
    public Product saveProduct(Product product) {
    	 product.setId(0);
        return productRepository.save(product);
    }

    @Override
    public Product findById(int id) {
        Optional<Product> optionalContainer = productRepository.findById(id);
        if (optionalContainer.isPresent())
            return optionalContainer.get();
        else
            throw new ProductIdNotFoundException(id);
    }

    @Override
    public List<Product> findAll() {
        return productRepository.findAll();
    }

    @Override
    public List<Product> findByName(String name) {
        return productRepository.findByName(name);
    }
}