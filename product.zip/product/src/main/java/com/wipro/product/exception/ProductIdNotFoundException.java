package com.wipro.product.exception;

public class ProductIdNotFoundException extends RuntimeException {

    public ProductIdNotFoundException(int id) {
        super("Product not found with id: " + id);
    }
}