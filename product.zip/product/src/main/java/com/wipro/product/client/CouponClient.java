package com.wipro.product.client;

import java.util.List;

import org.springframework.cloud.openfeign.FeignClient;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.wipro.product.dto.response.CouponDto;

@FeignClient(name = "COUPON")
public interface CouponClient {

    @GetMapping("/api/v1/coupons/code/{code}")
    List<CouponDto> getByCode(@PathVariable("code") String code);
}