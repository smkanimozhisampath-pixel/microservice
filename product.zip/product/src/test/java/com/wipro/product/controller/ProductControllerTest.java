package com.wipro.product.controller;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;
import static org.hamcrest.collection.IsCollectionWithSize.hasSize;

import java.util.Arrays;
import java.util.List;
import java.util.Random;
import java.util.UUID;

import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.test.web.servlet.MockMvc;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.wipro.product.dto.request.Product;
import com.wipro.product.exception.ProductIdNotFoundException;
import com.wipro.product.service.ProductService;

@WebMvcTest(ProductController.class)
public class ProductControllerTest {

    private static final String BASE_URL = "/api/v1/products";

    @MockitoBean // used to create mock object / dummy object
    private ProductService productService;

    @Autowired
    private MockMvc mockMvc; // to test the API

    @Autowired
    private ObjectMapper objectMapper;

    private final Random random = new Random();

    // generates a new product with random values each time
    private Product buildProduct() {
        Product product = new Product();
        product.setId(random.nextInt(1000) + 1);
        product.setName(UUID.randomUUID().toString());
        product.setPrice(random.nextInt(100000) + 1);
        product.setQuantity(random.nextInt(500) + 1);
        return product;
    }

    @Test // test case
    void testSaveProduct() throws Exception {
        // arrange
        Product actualProductRequestBody = buildProduct();

        when(productService.saveProduct(any(Product.class))).thenReturn(actualProductRequestBody);

        // act & assert
        mockMvc.perform(post(BASE_URL)
                    .contentType(MediaType.APPLICATION_JSON)
                    .content(objectMapper.writeValueAsString(actualProductRequestBody)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.id").value(actualProductRequestBody.getId()))
                .andExpect(jsonPath("$.name").value(actualProductRequestBody.getName()));
    }

    @Test
    void testGetProductById() throws Exception {
        // arrange
        Product product = buildProduct();

        when(productService.findById(product.getId())).thenReturn(product);

        // act & assert
        mockMvc.perform(get(BASE_URL + "/" + product.getId())
                        .contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.id").value(product.getId()))
                .andExpect(jsonPath("$.name").value(product.getName()));
    }

    @Test
    void testGetProductById_ProductNotFound() throws Exception {
        // arrange
        int missingId = random.nextInt(1000) + 1;

        when(productService.findById(missingId)).thenThrow(new ProductIdNotFoundException(missingId));

        // act & assert
        mockMvc.perform(get(BASE_URL + "/" + missingId))
                .andExpect(status().isNotFound());
        verify(productService).findById(missingId);
    }

    @Test
    void testGetAllProducts() throws Exception {
        // arrange
        Product first = buildProduct();
        Product second = buildProduct();
        List<Product> products = Arrays.asList(first, second);

        when(productService.findAll()).thenReturn(products);

        // act & assert
        mockMvc.perform(get(BASE_URL).contentType(MediaType.APPLICATION_JSON))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(products.size())))
                .andExpect(jsonPath("$[0].name").value(first.getName()))
                .andExpect(jsonPath("$[1].name").value(second.getName()));
    }

    @Test
    void testFindByName() throws Exception {
        // arrange
        Product product = buildProduct();
        List<Product> products = Arrays.asList(product);

        when(productService.findByName(product.getName())).thenReturn(products);

        // act & assert
        mockMvc.perform(get(BASE_URL + "/name/" + product.getName()))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$", hasSize(products.size())))
                .andExpect(jsonPath("$[0].name").value(product.getName()));
    }
}